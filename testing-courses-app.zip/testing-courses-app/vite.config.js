import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

// Compute absolute paths for alias resolution.  Vite uses native
// ESM, so we derive __dirname from ``import.meta.url``.  This allows
// the alias to point to the ``src`` directory no matter where the
// project is located on disk.
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
});
