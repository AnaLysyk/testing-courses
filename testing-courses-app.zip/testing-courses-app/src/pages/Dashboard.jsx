
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { 
  BookOpen, 
  Target, 
  Calendar, 
  MessageSquare, 
  Trophy,
  Flame,
  Award,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const Dashboard = () => {
  const { user } = useAuth();

  const stats = [
    { label: 'Pontos', value: user?.points || 0, icon: Trophy, color: 'text-yellow-600' },
    { label: 'Streak', value: `${user?.streak || 0} dias`, icon: Flame, color: 'text-orange-600' },
    { label: 'Badges', value: user?.badges?.length || 0, icon: Award, color: 'text-purple-600' },
    { label: 'Progresso', value: '45%', icon: TrendingUp, color: 'text-green-600' },
  ];

  const quickActions = [
    { title: 'Continuar Trilha', description: 'Testes de API com Postman', href: '/tracks', icon: BookOpen, color: 'bg-blue-500' },
    { title: 'Próxima Missão', description: 'Falha Controlada - Módulo 3', href: '/missions', icon: Target, color: 'bg-red-500' },
    { title: 'Plano de Estudos', description: 'Ver calendário semanal', href: '/study-plan', icon: Calendar, color: 'bg-green-500' },
    { title: 'Fórum QA', description: '3 novas discussões', href: '/forum', icon: MessageSquare, color: 'bg-purple-500' },
  ];

  return (
    <>
      <Helmet>
        <title>Dashboard - Testing Courses</title>
        <meta name="description" content="Acompanhe seu progresso, pontos e conquistas na plataforma Testing Courses" />
      </Helmet>

      <div className="space-y-6">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="gradient-bg rounded-2xl p-8 text-white"
        >
          <h1 className="text-3xl font-bold mb-2">
            Olá, {user?.name}! 👋
          </h1>
          <p className="text-white/80">
            Bem-vindo de volta! Continue sua jornada de aprendizado.
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</span>
                  <Icon className={`h-5 w-5 ${stat.color}`} />
                </div>
                <p className="text-2xl font-bold">{stat.value}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div>
          <h2 className="text-2xl font-bold mb-4">Ações Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.div
                  key={action.title}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link to={action.href}>
                    <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                      <div className="flex items-start space-x-4">
                        <div className={`${action.color} p-3 rounded-lg`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-1">{action.title}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{action.description}</p>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg">
          <h2 className="text-xl font-bold mb-4">Atividade Recente</h2>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full" />
              <p className="text-sm">Completou a aula "Introdução ao Postman"</p>
              <span className="text-xs text-gray-500 ml-auto">2h atrás</span>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="w-2 h-2 bg-blue-500 rounded-full" />
              <p className="text-sm">Ganhou badge "Primeiro Quiz"</p>
              <span className="text-xs text-gray-500 ml-auto">1 dia atrás</span>
            </div>
            <div className="flex items-center space-x-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <div className="w-2 h-2 bg-purple-500 rounded-full" />
              <p className="text-sm">Respondeu no fórum "Como criar testes de API"</p>
              <span className="text-xs text-gray-500 ml-auto">2 dias atrás</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
  