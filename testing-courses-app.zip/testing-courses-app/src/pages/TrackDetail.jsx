import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

// Import each track JSON so that they can be referenced by slug.  Each
// JSON file contains a ``track`` object with metadata (title, level,
// audience, hours_total) and a list of modules.  Modules themselves
// contain lessons and optional missions.
import gratuitoTrack from '@/data/gratuito.json';
import basicoTrack from '@/data/basico.json';
import intermediarioTrack from '@/data/intermediario.json';
import avancadoTrack from '@/data/avancado.json';

const tracksMap = {
  gratuito: gratuitoTrack,
  basico: basicoTrack,
  intermediario: intermediarioTrack,
  avancado: avancadoTrack,
};

/**
 * Page that renders the details of a particular track (trilha).  A
 * track is selected by its slug (``trackId``) from the URL
 * parameters.  If no matching track is found, the gratuito track is
 * shown as a fallback.  The page lists the modules within the track
 * and their lessons and mission titles.
 */
function TrackDetail() {
  const { trackId } = useParams();
  const track = tracksMap[trackId] ?? tracksMap.gratuito;

  const { title, level, audience, hours_total, modules } = track.track;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-primary mb-1">{title}</h1>
        <p className="text-muted-foreground mb-2">{audience}</p>
        <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-1 sm:space-y-0 text-sm">
          <span><strong>Nível:</strong> {level}</span>
          <span><strong>Duração:</strong> {hours_total}h</span>
          <span><strong>Módulos:</strong> {modules.length}</span>
        </div>
      </div>

      <div className="space-y-4">
        {modules.map((module, index) => (
          <div
            key={index}
            className="border border-border rounded-xl p-4 bg-card/60"
          >
            <h2 className="text-xl font-semibold text-primary mb-2">
              {module.title}
            </h2>
            {module.objectives && (
              <p className="text-sm text-muted-foreground mb-2">
                {module.objectives.join(', ')}
              </p>
            )}
            {module.lessons?.length > 0 && (
              <div className="mt-3">
                <h3 className="font-medium text-md mb-1">Lições</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  {module.lessons.map((lesson, li) => (
                    <li key={li}>{lesson.title}</li>
                  ))}
                </ul>
              </div>
            )}
            {module.mission && (
              <div className="mt-3">
                <h3 className="font-medium text-md mb-1">Missão</h3>
                <p className="text-sm italic text-primary-foreground">
                  {module.mission.type.replace(/_/g, ' ')}
                </p>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="pt-4">
        <Link to="/dashboard/tracks">
          <Button variant="secondary">Voltar às Trilhas</Button>
        </Link>
      </div>
    </div>
  );
}

export default TrackDetail;
