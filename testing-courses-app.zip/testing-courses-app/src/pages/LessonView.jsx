
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowLeft, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const LessonView = () => {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const [quizAnswers, setQuizAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const lesson = {
    id: lessonId,
    title: 'O que é Postman?',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    content: 'Postman é uma plataforma de colaboração para desenvolvimento de APIs...',
    quiz: [
      {
        id: '1',
        question: 'O que é o Postman?',
        options: [
          'Um editor de código',
          'Uma plataforma para testar APIs',
          'Um banco de dados',
          'Um framework JavaScript',
        ],
        correct: 1,
      },
      {
        id: '2',
        question: 'Qual método HTTP é usado para buscar dados?',
        options: ['POST', 'PUT', 'GET', 'DELETE'],
        correct: 2,
      },
    ],
  };

  const handleQuizSubmit = () => {
    const correctAnswers = lesson.quiz.filter(
      (q) => quizAnswers[q.id] === q.correct
    ).length;
    const percentage = (correctAnswers / lesson.quiz.length) * 100;

    setShowResults(true);

    if (percentage >= 70) {
      toast({
        title: "Parabéns! 🎉",
        description: `Você acertou ${correctAnswers} de ${lesson.quiz.length} questões (${percentage}%)`,
      });
    } else {
      toast({
        title: "Tente novamente",
        description: `Você precisa de pelo menos 70% para passar. Você obteve ${percentage}%`,
        variant: "destructive",
      });
    }
  };

  return (
    <>
      <Helmet>
        <title>{lesson.title} - Testing Courses</title>
        <meta name="description" content={`Aprenda sobre ${lesson.title} na plataforma Testing Courses`} />
      </Helmet>

      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar
        </Button>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden"
        >
          <div className="aspect-video bg-black">
            <iframe
              src={lesson.videoUrl}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          <div className="p-6">
            <h1 className="text-2xl font-bold mb-4">{lesson.title}</h1>
            <p className="text-gray-600 dark:text-gray-400">{lesson.content}</p>
          </div>
        </motion.div>

        {/* Quiz */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
        >
          <h2 className="text-xl font-bold mb-6">Quiz de Verificação</h2>

          <div className="space-y-6">
            {lesson.quiz.map((question, qIndex) => (
              <div key={question.id} className="space-y-3">
                <p className="font-medium">
                  {qIndex + 1}. {question.question}
                </p>
                <div className="space-y-2">
                  {question.options.map((option, oIndex) => (
                    <label
                      key={oIndex}
                      className={`
                        flex items-center space-x-3 p-3 rounded-lg border-2 cursor-pointer transition-colors
                        ${quizAnswers[question.id] === oIndex
                          ? 'border-[#001953] bg-[#001953]/5'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                        }
                        ${showResults && oIndex === question.correct
                          ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                          : ''
                        }
                        ${showResults && quizAnswers[question.id] === oIndex && oIndex !== question.correct
                          ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                          : ''
                        }
                      `}
                    >
                      <input
                        type="radio"
                        name={`question-${question.id}`}
                        checked={quizAnswers[question.id] === oIndex}
                        onChange={() => setQuizAnswers({ ...quizAnswers, [question.id]: oIndex })}
                        disabled={showResults}
                        className="text-[#001953]"
                      />
                      <span>{option}</span>
                      {showResults && oIndex === question.correct && (
                        <CheckCircle className="h-5 w-5 text-green-500 ml-auto" />
                      )}
                    </label>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {!showResults && (
            <Button
              onClick={handleQuizSubmit}
              className="w-full mt-6 bg-[#001953] hover:bg-[#001953]/90"
              disabled={Object.keys(quizAnswers).length !== lesson.quiz.length}
            >
              Enviar Respostas
            </Button>
          )}

          {showResults && (
            <div className="flex space-x-4 mt-6">
              <Button
                onClick={() => {
                  setQuizAnswers({});
                  setShowResults(false);
                }}
                variant="outline"
                className="flex-1"
              >
                Tentar Novamente
              </Button>
              <Button
                onClick={() => navigate(-1)}
                className="flex-1 bg-[#001953] hover:bg-[#001953]/90"
              >
                Próxima Aula
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          )}
        </motion.div>
      </div>
    </>
  );
};

export default LessonView;
  