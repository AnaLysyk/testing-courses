
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Users, Calendar, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';

const Mentorship = () => {
  const mentors = [
    {
      id: '1',
      name: 'Ana Souza',
      bio: 'Especialista em Testes Automatizados e API Testing',
      areas: ['Testes de API', 'Cypress', 'Postman'],
      available: true,
    },
    {
      id: '2',
      name: 'Carlos Lima',
      bio: 'Expert em Performance Testing e JMeter',
      areas: ['Performance', 'JMeter', 'K6'],
      available: false,
    },
    {
      id: '3',
      name: 'Fernanda Alves',
      bio: 'Mobile Testing Specialist',
      areas: ['Mobile', 'Appium', 'Android', 'iOS'],
      available: true,
    },
    {
      id: '4',
      name: 'Ricardo Silva',
      bio: 'QA Estratégico e Testes Manuais',
      areas: ['Estratégia', 'Testes Manuais', 'Exploratórios'],
      available: true,
    },
  ];

  const appointments = [
    {
      id: '1',
      mentor: 'Ana Souza',
      date: '15/06/2025',
      time: '14:00',
      status: 'confirmed',
    },
    {
      id: '2',
      mentor: 'Ricardo Silva',
      date: '20/06/2025',
      time: '10:00',
      status: 'pending',
    },
  ];

  const handleRequestMentorship = (mentorId) => {
    toast({
      title: "Solicitação enviada!",
      description: "🚧 Este recurso ainda não está implementado—mas você pode solicitá-lo no próximo prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Mentorias - Testing Courses</title>
        <meta name="description" content="Agende mentorias com especialistas em testes de software e acelere seu aprendizado" />
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Mentorias</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Conecte-se com mentores especialistas
          </p>
        </div>

        {/* My Appointments */}
        {appointments.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
          >
            <h2 className="text-xl font-bold mb-4">Minhas Mentorias</h2>
            <div className="space-y-3">
              {appointments.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-[#001953]" />
                    <div>
                      <p className="font-semibold">{appointment.mentor}</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {appointment.date} às {appointment.time}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-semibold ${
                      appointment.status === 'confirmed'
                        ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400'
                        : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'
                    }`}
                  >
                    {appointment.status === 'confirmed' ? (
                      <>
                        <CheckCircle className="h-4 w-4" />
                        <span>Confirmada</span>
                      </>
                    ) : (
                      <>
                        <Clock className="h-4 w-4" />
                        <span>Pendente</span>
                      </>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Mentors */}
        <div>
          <h2 className="text-xl font-bold mb-4">Nossos Mentores</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {mentors.map((mentor, index) => (
              <motion.div
                key={mentor.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
              >
                <div className="flex items-start space-x-4 mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarFallback className="bg-[#001953] text-white text-xl">
                      {mentor.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold mb-1">{mentor.name}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      {mentor.bio}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {mentor.areas.map((area) => (
                        <span
                          key={area}
                          className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded text-xs font-medium"
                        >
                          {area}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span
                    className={`text-sm font-semibold ${
                      mentor.available
                        ? 'text-green-600 dark:text-green-400'
                        : 'text-red-600 dark:text-red-400'
                    }`}
                  >
                    {mentor.available ? 'Disponível' : 'Indisponível'}
                  </span>
                  <Button
                    onClick={() => handleRequestMentorship(mentor.id)}
                    disabled={!mentor.available}
                    className="bg-[#001953] hover:bg-[#001953]/90"
                  >
                    Agendar Mentoria
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Mentorship;
  