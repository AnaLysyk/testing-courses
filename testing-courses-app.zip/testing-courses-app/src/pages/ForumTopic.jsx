
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ThumbsUp, MessageCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { toast } from '@/components/ui/use-toast';

const ForumTopic = () => {
  const { topicId } = useParams();
  const navigate = useNavigate();
  const [reply, setReply] = useState('');

  const topic = {
    id: topicId,
    title: 'Como criar testes de API com Postman?',
    author: 'Ana Silva',
    content: 'Olá! Estou começando a criar testes de API e gostaria de entender como estruturar os testes no Postman. Alguém pode compartilhar boas práticas?',
    createdAt: '06/06/2025 14:32',
    views: 120,
    replies: [
      {
        id: '1',
        author: 'Carlos Lima',
        content: 'Oi Ana! No Postman você pode usar a aba "Tests" para escrever scripts em JavaScript. Uma boa prática é criar coleções organizadas e usar variáveis de ambiente.',
        createdAt: '06/06/2025 16:20',
        likes: 4,
        isSolution: false,
      },
      {
        id: '2',
        author: 'Fernanda Alves',
        content: 'Também recomendo usar o Postman CLI (Newman) para integrar com CI/CD. Você pode exportar suas coleções e rodar os testes automaticamente!',
        createdAt: '06/06/2025 18:45',
        likes: 7,
        isSolution: true,
      },
    ],
  };

  const handleSubmitReply = () => {
    if (!reply.trim()) return;
    
    toast({
      title: "Resposta enviada!",
      description: "Sua resposta foi publicada com sucesso",
    });
    setReply('');
  };

  const handleLike = (replyId) => {
    toast({
      title: "Curtido!",
      description: "🚧 Este recurso ainda não está implementado—mas você pode solicitá-lo no próximo prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>{topic.title} - Fórum QA</title>
        <meta name="description" content={topic.content} />
      </Helmet>

      <div className="space-y-6">
        <Button
          variant="ghost"
          onClick={() => navigate('/forum')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar ao Fórum
        </Button>

        {/* Topic */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
        >
          <h1 className="text-2xl font-bold mb-4">{topic.title}</h1>

          <div className="flex items-center space-x-3 mb-4">
            <Avatar>
              <AvatarFallback className="bg-[#001953] text-white">
                {topic.author.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold">{topic.author}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Postado em {topic.createdAt}
              </p>
            </div>
          </div>

          <p className="text-gray-700 dark:text-gray-300 mb-4">{topic.content}</p>

          <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
            <span className="flex items-center space-x-1">
              <MessageCircle className="h-4 w-4" />
              <span>{topic.replies.length} respostas</span>
            </span>
            <span>{topic.views} visualizações</span>
          </div>
        </motion.div>

        {/* Replies */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Respostas</h2>
          {topic.replies.map((reply, index) => (
            <motion.div
              key={reply.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 ${
                reply.isSolution ? 'border-2 border-green-500' : ''
              }`}
            >
              {reply.isSolution && (
                <div className="flex items-center space-x-2 text-green-600 dark:text-green-400 mb-3">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-semibold">Solução Aceita</span>
                </div>
              )}

              <div className="flex items-center space-x-3 mb-4">
                <Avatar>
                  <AvatarFallback className="bg-[#001953] text-white">
                    {reply.author.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold">{reply.author}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {reply.createdAt}
                  </p>
                </div>
              </div>

              <p className="text-gray-700 dark:text-gray-300 mb-4">{reply.content}</p>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleLike(reply.id)}
              >
                <ThumbsUp className="h-4 w-4 mr-2" />
                {reply.likes} Útil
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Reply Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
        >
          <h3 className="text-lg font-bold mb-4">Sua Resposta</h3>
          <Textarea
            placeholder="Escreva sua resposta..."
            value={reply}
            onChange={(e) => setReply(e.target.value)}
            rows={5}
            className="mb-4"
          />
          <Button
            onClick={handleSubmitReply}
            className="bg-[#001953] hover:bg-[#001953]/90"
          >
            Enviar Resposta
          </Button>
        </motion.div>
      </div>
    </>
  );
};

export default ForumTopic;
  