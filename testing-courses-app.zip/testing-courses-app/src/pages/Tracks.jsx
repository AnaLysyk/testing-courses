import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Lock, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import gratuitoTrack from '@/data/tracks/gratuito.json';
import basicoTrack from '@/data/tracks/basico.json';
import intermediarioTrack from '@/data/tracks/intermediario.json';
import avancadoTrack from '@/data/tracks/avancado.json';

const Tracks = () => {
  const [tracksData, setTracksData] = useState([]);

  useEffect(() => {
    const allTracks = [
      gratuitoTrack.track,
      basicoTrack.track,
      intermediarioTrack.track,
      avancadoTrack.track,
    ].map((track, index) => ({
      ...track,
      id: track.title.toLowerCase().replace(/\s+/g, '-'),
      // Mocking progress and locked status for demonstration
      progress: index === 0 ? 60 : index === 2 ? 45 : 0,
      locked: false,
    }));
    setTracksData(allTracks);
  }, []);

  const levelColors = {
    Gratuito: 'from-green-500 to-emerald-600',
    Basico: 'from-blue-500 to-cyan-600',
    Intermediario: 'from-orange-500 to-red-600',
    Avancado: 'from-purple-500 to-pink-600',
  };

  const tracksByLevel = tracksData.reduce((acc, track) => {
    const level = track.level;
    if (!acc[level]) {
      acc[level] = [];
    }
    acc[level].push(track);
    return acc;
  }, {});

  const levelOrder = ['Gratuito', 'Basico', 'Intermediario', 'Avancado'];

  return (
    <>
      <Helmet>
        <title>Trilhas de Aprendizado - Testing Courses</title>
        <meta name="description" content="Explore nossas trilhas de aprendizado em testes de software, desde o básico até o avançado" />
      </Helmet>

      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">Trilhas de Aprendizado</h1>
          <p className="text-muted-foreground">
            Escolha sua trilha e comece a aprender testes de software.
          </p>
        </div>

        {levelOrder.map(level => tracksByLevel[level] && (
          <div key={level}>
            <h2 className="text-2xl font-bold mb-4 border-b-2 border-primary pb-2">{level}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tracksByLevel[level].map((track, index) => (
                <motion.div
                  key={track.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-card rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col"
                >
                  <div className={`h-36 bg-gradient-to-br ${levelColors[track.level]} p-6 flex flex-col justify-between`}>
                    <div>
                       <span className="inline-block px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full text-white text-xs font-semibold mb-2">
                        {track.level}
                      </span>
                      <h3 className="text-xl font-bold text-white">{track.title}</h3>
                    </div>
                  </div>

                  <div className="p-6 flex-grow flex flex-col">
                    <p className="text-muted-foreground text-sm mb-4 flex-grow">
                      {track.audience.substring(0, 150)}{track.audience.length > 150 && '...'}
                    </p>

                    <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-4">
                       <div className="flex items-center space-x-1">
                        <BookOpen className="h-4 w-4" />
                        <span>{track.modules.length} módulos</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{track.hours_total} horas</span>
                      </div>
                    </div>

                    {track.progress > 0 && (
                      <div className="w-full bg-muted rounded-full h-2 mb-4">
                        <div
                          className={`h-2 rounded-full bg-gradient-to-r ${levelColors[track.level]}`}
                          style={{ width: `${track.progress}%` }}
                        />
                      </div>
                    )}

                    <Link to={`/tracks/${track.id}`} className="mt-auto">
                      <Button variant="destructive" className="w-full" disabled={track.locked}>
                        {track.locked ? 'Em breve' : track.progress > 0 ? 'Continuar' : 'Iniciar Trilha'}
                      </Button>
                    </Link>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default Tracks;