
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Trophy, Medal, Award } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';

const Leaderboard = () => {
  const { user } = useAuth();

  const rankings = [
    { id: '1', name: 'João Silva', points: 1250, rank: 1 },
    { id: '2', name: 'Maria Santos', points: 1180, rank: 2 },
    { id: '3', name: 'Pedro Costa', points: 1050, rank: 3 },
    { id: '4', name: user?.name || 'Você', points: user?.points || 0, rank: 4, isCurrentUser: true },
    { id: '5', name: 'Ana Paula', points: 890, rank: 5 },
    { id: '6', name: 'Carlos Eduardo', points: 820, rank: 6 },
    { id: '7', name: 'Juliana Lima', points: 750, rank: 7 },
    { id: '8', name: 'Roberto Alves', points: 680, rank: 8 },
  ];

  const getRankIcon = (rank) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />;
      case 3:
        return <Award className="h-6 w-6 text-orange-600" />;
      default:
        return <span className="text-lg font-bold text-gray-500">#{rank}</span>;
    }
  };

  return (
    <>
      <Helmet>
        <title>Ranking - Testing Courses</title>
        <meta name="description" content="Veja o ranking dos melhores alunos da plataforma Testing Courses" />
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Ranking Global</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Veja os melhores alunos da plataforma
          </p>
        </div>

        {/* Top 3 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {rankings.slice(0, 3).map((player, index) => (
            <motion.div
              key={player.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`
                bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center
                ${index === 0 ? 'md:order-2 md:scale-110' : ''}
                ${index === 1 ? 'md:order-1' : ''}
                ${index === 2 ? 'md:order-3' : ''}
              `}
            >
              <div className="flex justify-center mb-4">
                {getRankIcon(player.rank)}
              </div>
              <Avatar className="h-20 w-20 mx-auto mb-4">
                <AvatarFallback className="bg-[#001953] text-white text-2xl">
                  {player.name.charAt(0)}
                </AvatarFallback>
              </Avatar>
              <h3 className="text-lg font-bold mb-2">{player.name}</h3>
              <p className="text-2xl font-bold text-[#D90429]">{player.points} pts</p>
            </motion.div>
          ))}
        </div>

        {/* Rest of rankings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden"
        >
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {rankings.slice(3).map((player, index) => (
              <div
                key={player.id}
                className={`
                  p-4 flex items-center justify-between
                  ${player.isCurrentUser ? 'bg-blue-50 dark:bg-blue-900/20' : ''}
                `}
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 text-center">
                    {getRankIcon(player.rank)}
                  </div>
                  <Avatar>
                    <AvatarFallback className="bg-[#001953] text-white">
                      {player.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">
                      {player.name}
                      {player.isCurrentUser && (
                        <span className="ml-2 text-xs text-blue-600 dark:text-blue-400">(Você)</span>
                      )}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold text-[#D90429]">{player.points} pts</p>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default Leaderboard;
  