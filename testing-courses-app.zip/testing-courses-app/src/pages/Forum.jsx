
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MessageSquare, ThumbsUp, MessageCircle, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Forum = () => {
  const categories = [
    { id: '1', name: 'Testes Manuais', color: 'bg-green-500' },
    { id: '2', name: 'Automação', color: 'bg-blue-500' },
    { id: '3', name: 'Ferramentas', color: 'bg-purple-500' },
    { id: '4', name: 'Carreira', color: 'bg-orange-500' },
    { id: '5', name: 'Outros', color: 'bg-gray-500' },
  ];

  const topics = [
    {
      id: '1',
      title: 'Como criar testes de API com Postman?',
      author: 'Ana Silva',
      category: 'Automação',
      replies: 3,
      views: 120,
      likes: 10,
      lastActivity: '2h atrás',
    },
    {
      id: '2',
      title: 'Problemas com XPath no Selenium',
      author: 'Carlos Lima',
      category: 'Ferramentas',
      replies: 5,
      views: 89,
      likes: 7,
      lastActivity: '5h atrás',
    },
    {
      id: '3',
      title: 'Estratégias para testes mobile',
      author: 'Fernanda Alves',
      category: 'Testes Manuais',
      replies: 2,
      views: 45,
      likes: 5,
      lastActivity: '1 dia atrás',
    },
  ];

  const handleNewTopic = () => {
    toast({
      title: "Novo tópico",
      description: "🚧 Este recurso ainda não está implementado—mas você pode solicitá-lo no próximo prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Fórum QA - Testing Courses</title>
        <meta name="description" content="Participe das discussões da comunidade Testing Courses e tire suas dúvidas sobre testes de software" />
      </Helmet>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Fórum QA</h1>
            <p className="text-gray-600 dark:text-gray-400">
              Participe das discussões da comunidade
            </p>
          </div>
          <Button onClick={handleNewTopic} className="bg-[#001953] hover:bg-[#001953]/90">
            <Plus className="h-4 w-4 mr-2" />
            Novo Tópico
          </Button>
        </div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6"
        >
          <h2 className="text-lg font-bold mb-4">Categorias</h2>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <button
                key={category.id}
                className={`${category.color} text-white px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Topics */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Tópicos Recentes</h2>
          {topics.map((topic, index) => (
            <motion.div
              key={topic.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={`/forum/${topic.id}`}>
                <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold mb-2">{topic.title}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                        <span>Por {topic.author}</span>
                        <span>•</span>
                        <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 rounded">
                          {topic.category}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center space-x-1">
                        <MessageCircle className="h-4 w-4" />
                        <span>{topic.replies} respostas</span>
                      </span>
                      <span className="flex items-center space-x-1">
                        <ThumbsUp className="h-4 w-4" />
                        <span>{topic.likes}</span>
                      </span>
                      <span>{topic.views} visualizações</span>
                    </div>
                    <span>{topic.lastActivity}</span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Forum;
  