
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Missions = () => {
  const missions = [
    {
      id: '1',
      title: 'Falha Controlada - Módulo 1',
      type: 'Falha Controlada',
      description: 'Identifique e documente 3 falhas em um sistema de login',
      points: 40,
      status: 'completed',
      grade: 95,
    },
    {
      id: '2',
      title: 'Bug Report - Módulo 2',
      type: 'Bug Report',
      description: 'Crie um relatório detalhado de bug seguindo o template fornecido',
      points: 40,
      status: 'available',
    },
    {
      id: '3',
      title: 'Caso de Teste - Módulo 3',
      type: 'Caso de Teste',
      description: 'Escreva casos de teste para funcionalidade de carrinho de compras',
      points: 40,
      status: 'locked',
    },
  ];

  const handleStartMission = (missionId) => {
    toast({
      title: "Iniciando missão...",
      description: "🚧 Este recurso ainda não está implementado—mas você pode solicitá-lo no próximo prompt! 🚀",
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'text-green-600 bg-green-100 dark:bg-green-900/30';
      case 'available':
        return 'text-blue-600 bg-blue-100 dark:bg-blue-900/30';
      case 'locked':
        return 'text-gray-600 bg-gray-100 dark:bg-gray-700';
      default:
        return '';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5" />;
      case 'available':
        return <Clock className="h-5 w-5" />;
      case 'locked':
        return <AlertCircle className="h-5 w-5" />;
      default:
        return null;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'completed':
        return 'Concluída';
      case 'available':
        return 'Disponível';
      case 'locked':
        return 'Bloqueada';
      default:
        return '';
    }
  };

  return (
    <>
      <Helmet>
        <title>QA Missions - Testing Courses</title>
        <meta name="description" content="Complete missões práticas e ganhe pontos extras na sua jornada de aprendizado" />
      </Helmet>

      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">QA Missions</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Complete missões práticas e ganhe pontos extras
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {missions.map((mission, index) => (
            <motion.div
              key={mission.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Target className="h-6 w-6 text-[#D90429]" />
                    <span className="text-xs font-semibold text-gray-500 dark:text-gray-400">
                      {mission.type}
                    </span>
                  </div>
                  <span className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-semibold ${getStatusColor(mission.status)}`}>
                    {getStatusIcon(mission.status)}
                    <span>{getStatusText(mission.status)}</span>
                  </span>
                </div>

                <h3 className="text-lg font-bold mb-2">{mission.title}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  {mission.description}
                </p>

                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-semibold text-yellow-600 dark:text-yellow-400">
                    +{mission.points} pontos
                  </span>
                  {mission.status === 'completed' && mission.grade && (
                    <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                      Nota: {mission.grade}%
                    </span>
                  )}
                </div>

                <Button
                  onClick={() => handleStartMission(mission.id)}
                  className="w-full"
                  disabled={mission.status === 'locked'}
                  variant={mission.status === 'completed' ? 'outline' : 'default'}
                >
                  {mission.status === 'completed' ? 'Ver Resultado' : mission.status === 'available' ? 'Iniciar Missão' : 'Bloqueada'}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Missions;
  